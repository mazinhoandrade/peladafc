<div class="container-fluid desk">
    <div class="messagem">
        {{$slot}}
    </div>
</div>
