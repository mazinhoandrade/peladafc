<?php $__env->startSection('titulo' , 'Area de Login'); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .bl {
            display: none;
        }
    </style>

<?php if(session('warning')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <?php echo e(session('warning')); ?>

     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php endif; ?>


<div class="campo input-group">
    <form  method="POST">
        <?php echo csrf_field(); ?>
        <label>Usuario:</label>
        <input class="form-control" type="text"  name="name" >
        <label>Senha:</label>
        <input class="form-control" type="password" name="password">
        <input class="form-control" id="btn" type="submit" value="entrar">
    </form>
</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/auth/login.blade.php ENDPATH**/ ?>