

<?php $__env->startSection('titulo' , 'Painel'); ?>

<?php $__env->startSection('content'); ?>
<div class="campo">
    <form method="POST">
        <?php echo csrf_field(); ?>
        <label>Usuario:</label>
        <input type="text" name="user">
        <label>Senha:</label>
        <input type="password" name="senha">
        <input id="btn" type="submit" value="entra">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/login.blade.php ENDPATH**/ ?>