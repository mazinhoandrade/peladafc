<?php $__env->startSection('titulo' , 'Painel'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="container-fluid desk alert alert-danger">
            <h4><i class="icon fa fa-ban"></i> Ocorreu Erro(s)</h4>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($erro); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="container-fluid desk">


        <div class="row justify-content-between ">
            <div class="col-4">
                <h2>Lista do Baba</h2>
            </div>
        </div>

        <div class="container-fluid corcinza">
            <form id="atleta" action="<?php echo e(route('baba.update',$id_baba)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php $__currentLoopData = $dados_baba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado_baba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label>Data do baba:</label></br>
                    <input text="date" name="data" disabled value="<?php echo e(date('d/m/Y', strtotime($dado_baba->created_at))); ?>"></br>
                    <label>Descrição:</label></br>
                    <input type="text" name="descricao" value="<?php echo e($dado_baba->descricao); ?>" required></br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty($dados)): ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">:)</th>
                            <th scope="col">Nome:</th>
                            <th scope="col">Falhas:</th>
                            <th scope="col">Gols:</th>
                            <th scope="col">Assistecias:</th>
                            <th scope="col">Capa:</th>
                        </tr>
                        </thead>



                        <tbody>

                        <?php for($i = 0; $i < count($dados) ;$i++): ?>

                            <tr>
                                <td><input type="hidden" name="id[]" value="<?php echo e($dados[$i]["id"]); ?>"></td>
                                <td><input type="text" name="" value="<?php echo e(App\Models\Baba::nomeAtleta($dados[$i]["id"])); ?>" disabled></td>
                                <td><input type="number" min="0" name="falhas[]" value="<?php echo e($dados[$i]["pivot"]["falhas"]); ?>" required></td>
                                <td><input type="number" min="0" name="gols[]" value="<?php echo e($dados[$i]["pivot"]["gols"]); ?>" required></td>
                                <td><input type="number" min="0" name="assis[]" id="nun" value="<?php echo e($dados[$i]["pivot"]["assistecias"]); ?>" required></td>
                                <td><input type="number" min="0" name="capa[]" id="nun" value="<?php echo e($dados[$i]["pivot"]["is_veceu_baba"]); ?>" required></td>
                            </tr>
                        <?php endfor; ?>
                        </tbody>


                    </table>

                    <hr/>
                    <input id="btn" type="submit" onclick="return validateForm()" value="Editar Baba">
                <?php endif; ?>
            </form>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/baba/edit.blade.php ENDPATH**/ ?>