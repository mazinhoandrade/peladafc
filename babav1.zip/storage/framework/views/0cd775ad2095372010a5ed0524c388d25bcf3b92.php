<?php $__env->startSection('titulo' , 'Amigos da Bola'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
<?php $__env->startSection('content'); ?>

    <div class="container-fluid desk">
        <h1>Aniversariante(s) do Mes </h1>
        <div class="row justify-content-center align-items-start">
                <?php $__empty_1 = true; $__currentLoopData = $anis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ani): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-6 col-xl-4">
                        <div class="campoAniversario row justify-content-start">
                            <img class="img-responsive" src="<?php echo e(asset('storage/media/imgat/'.$ani->avatar)); ?>">
                            <div class="titulo col-12"><?php echo e($ani->nome); ?></div>
                            <div class="data col-12"><?php echo e(date('d/m', strtotime($ani->data_aniversario))); ?></div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <b>Nenhum Aniversariante(s) Neste Mes!</b>
            <?php endif; ?>

        </div>
    </div>

    <div class="container-fluid desk">
        <h1>Os Melhores da Semana </h1>
        <div class="row justify-content-center align-items-start">
            <?php if(!empty($tops_semana)): ?>

                <?php for($i=0; $i<count($tops_semana); $i++): ?>
                    <div class="col-6 col-xl-4">
                        <div class="campoAniversario row justify-content-start">
                            <img class="img-responsive"
                                 src="<?php echo e(asset("storage/media/imgat/".$tops_semana[$i]['avatar'])); ?>">
                            <div class="titulo col-12"><?php echo e($tops_semana[$i]["nome"]); ?></div>
                        </div>
                    </div>
                <?php endfor; ?>

            <?php else: ?>
                <b>Nenhum atleta encotrado!</b>
            <?php endif; ?>


        </div>
    </div>

    <div class="container-fluid desk">
        <div class="row align-items-center">
            <div class="col col-xl-4">
                <h1>Ranking Geral</h1>
            </div>

            <div class="col btn">
                <select name="ranking" id="ranking">
                    <option value="">Escolha</option>
                    <option value="0">Gols</option>
                    <option value="1">assistência</option>
                    <option value="2">Falhas</option>
                    <option value="3">Capas</option>
                </select>
            </div>
        </div>
        <div class="row justify-content-center align-items-start">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">Foto</th>
                    <th scope="col">Nome</th>
                    <th scope="col">
                        <?php if(key($_REQUEST) === 1): ?>
                            assistências
                        <?php elseif(key($_REQUEST) === 2): ?>
                            falhas
                        <?php elseif(key($_REQUEST) === 3): ?>
                            capas
                        <?php else: ?>
                            gols
                        <?php endif; ?>
                    </th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><img width="60" height="60" src="<?php echo e(asset('storage/media/imgat/'.$top->avatar)); ?>"
                                 alt="img-atleta"></td>
                        <td><?php echo e($top->nome); ?></td>
                        <td>
                            <?php if(key($_REQUEST) === 1): ?>
                                <?php echo e($top->t_assistecias); ?>

                            <?php elseif(key($_REQUEST) === 2): ?>
                                <?php echo e($top->t_falhas); ?>

                            <?php elseif(key($_REQUEST) === 3): ?>
                                <?php echo e($top->t_capas); ?>

                            <?php else: ?>
                                <?php echo e($top->t_gols); ?>

                            <?php endif; ?>
                        </td>
                </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $('#ranking').change(function () {
            let parametro = $(this).find(':selected').val()
            location.href = '?' + parametro;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/home.blade.php ENDPATH**/ ?>