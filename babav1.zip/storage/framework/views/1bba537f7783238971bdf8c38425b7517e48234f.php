<?php $__env->startSection('titulo' , 'Painel'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div class="container-fluid desk alert alert-danger">
    <h4><i class="icon fa fa-ban"></i> Ocorreu Erro(s)</h4>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($erro); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="container-fluid desk">


    <div class="container-fluid corcinza">
        <form action="<?php echo e(route('baba.storeli')); ?>" method="POST">
            <div class="row justify-content-between">

                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $atletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-xl-3">
                        <input type="checkbox" name="<?php echo e($atleta->id); ?>" value="<?php echo e($atleta->nome); ?>"/> <?php echo e($atleta->nome); ?><br/>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <input id="btn" type="submit" value="add atletas na lista">

        </form>
    </div>

    <div class="row justify-content-between ">
        <div class="col col-xl-3">
            <h2>Lista do Baba</h2>
        </div>
    </div>

    <div class="container-fluid corcinza">
        <form id="baba" action="<?php echo e(route('baba.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label>Data do baba:</label></br>
            <input type="date" name="data"></br>
            <label>Descrição:</label></br>
            <input class="mb-2" type="text" name="descricao" required></br>
            <?php if(!empty($listas)): ?>
            <table class=".table-striped">
                <thead class="mb-1">
                    <tr>
                        <th scope="col "></th>
                        <th scope="col">Nome:</th>
                        <th scope="col mr-1">Falhas:</th>
                        <th scope="col">Gols:</th>
                        <th scope="col">Assistecias:</th>
                        <th scope="col">Capa:</th>
                    </tr>
                </thead >

                <tbody>

                    <?php $__currentLoopData = $listas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr style="margin-bottom: 5px">
                        <td><input type="hidden" name="id[]" value="<?php echo e($key); ?>"></td>
                        <td><input class="td-input" type="text" name="<?php echo e($lista); ?>" value="<?php echo e($lista); ?>" disabled></td>
                        <td><input class="" type="number" min="0" name="falhas[]" value="0" required></td>
                        <td><input class="" type="number" min="0" name="gols[]"   value="0" required></td>
                        <td><input class="" type="number" min="0" name="assis[]" id="nun"  value="0" required></td>
                        <td><input class="" type="number" min="0" name="capa[]" id="nun"  value="0" required></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>



            </table>

            <hr />
            <input id="btn" type="submit" onclick="return validateForm()" value="Cadastrar Baba">
            <?php endif; ?>
        </form>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/baba/create.blade.php ENDPATH**/ ?>