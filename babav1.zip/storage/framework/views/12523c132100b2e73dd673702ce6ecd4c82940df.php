<?php $__env->startSection('titulo' , 'Painel'); ?>

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="container-fluid desk alert alert-danger">
            <h4><i class="icon fa fa-ban"></i> Ocorreu Erro(s)</h4>
            <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($erro); ?></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<div class="container-fluid desk">
    <div class="row justify-content-between ">
        <div class="col-4">
            <h2>Cadastra Atleta</h2>
        </div>
    </div>

    <div class="container-fluid corcinza">
        <form id="atleta" action="<?php echo e(route('atleta.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label>Nome Do Atleta:</label></br>
            <input type="text" name="nome"></br>
            <label>Posição do Atleta:</label></br>
            <select  name="posisao">
                <option value="1">Goleiro Linha</option>
                <option value="2" selected>Fixo</option>
                <option value="3">Ala Esquerda</option>
                <option value="4">Ala Direita</option>
                <option value="5">Pivô</option>
            </select>
            <label>Data de Nacimento:</label></br>
            <input type="date" name="data_aniversario"></br>
            <label>Foto Do Atleta (jpg,png):</label></br>
            <input type="file" name="avatar">
            <hr />
            <input id="btn" type="submit" value="Adicionar atleta">
        </form>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/atletas/create.blade.php ENDPATH**/ ?>