<?php $__env->startSection('titulo' , 'Lista de Atletas'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->startSection('content'); ?>

    <div class="container-fluid desk">
        <h1>Atletas Amigos da Bola</h1>
        <div class="row justify-content-center align-items-start">

            <?php $__currentLoopData = $atletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-xl-6">
                    <div class="areaatletas col-12 col-xl-12 row justify-content-start">
                        <div class="col-12 col-xl-6">
                            <img class="img-responsive" src="<?php echo e(asset('storage/media/imgat/'.$atleta->avatar)); ?>">
                        </div>
                        <div class="row col-12 col-xl-12">
                            <div class="titulo col-12"><?php echo e($atleta->nome); ?></div>
                            <div class="infoa col">
                                <b>Posição: </b><?php echo e(App\Models\Atleta::posicao($atleta->posisao)); ?><br />
                                <b>Idade: </b><?php echo e(date('Y') - date('Y', strtotime($atleta->data_aniversario))); ?> Anos<br />
                                <b>Gols: </b><?php echo e($atleta->t_gols); ?><br />
                                <b>Assistecias: </b><?php echo e($atleta->t_assistecias); ?><br />
                                <b>Falhas: </b><?php echo e($atleta->t_falhas); ?><br />
                                <b>Capas: </b><?php echo e($atleta->t_capas); ?> vezes<br />
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($atletas->links('pagination::bootstrap-4')); ?>

    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/atleta.blade.php ENDPATH**/ ?>