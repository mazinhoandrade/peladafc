<?php $__env->startSection('titulo' , 'Painel'); ?>

<?php $__env->startSection('content'); ?>


    <div class="container-fluid desk">
        <div class="row justify-content-between ">
            <div class="col col-xl-4">
                <h2>Lista dos Babas</h2>
            </div>
            <div class="col-4">
            <h3><a href="baba/create"><b style="color: black;">Add Baba</b></a></h3>
            </div>
        </div>
    </div>

    <div class="container-fluid desk corcinza">
    <table class=".table">
  <thead>
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">Data do Baba</th>
      <th scope="col">Descrição</th>
      <th>Ações</th>
    </tr>
  </thead>

  <?php $__currentLoopData = $babas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tbody>
  <tr>
                    <td><?php echo e($baba->id); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($baba->created_at))); ?></td>
                    <td><?php echo e($baba->descricao); ?></td>
                    <td>
                        <a href="<?php echo e(route('baba.edit', $baba->id)); ?>" class="btn btn-sm"><img src="http://127.0.0.1:8000/storage/media/img/edit.png" width="30px"></a>


                            <form class="d-inline" method="POST" action="<?php echo e(route('baba.destroy', $baba->id )); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button onclick="return confirm('tem certeza que deseja excluir?')" class="btn btn-sm btn-danger"><img src="http://127.0.0.1:8000/storage/media/img/del.png" width="30px"></button>
                            </form>

                    </td>
                </tr>
  </tbody>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
    </div>
    <div class="container-fluid desk">
            <?php echo e($babas->links('pagination::bootstrap-4')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/baba/index.blade.php ENDPATH**/ ?>