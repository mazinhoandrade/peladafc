<?php $__env->startSection('titulo' , 'Painel'); ?>

<?php $__env->startSection('content'); ?>


    <div class="container-fluid desk">
        <div class="row justify-content-between ">
            <div class="col col-xl-4">
                <h2>Ficha dos Atletas</h2>
            </div>

        </div>
    </div>

    <div class="container-fluid desk corcinza">
    <table class=".table">
  <thead>
    <tr>
      <th scope="col">Foto</th>
      <th scope="col">Nome</th>
      <th scope="col">Posição</th>
      <th scope="col">Data De Nacimento</th>
      <th>Ações</th>
    </tr>
  </thead>

  <?php $__currentLoopData = $atletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tbody>
  <tr>
                    <td><img width="60" height="60" src="<?php echo e(asset('storage/media/imgat/'.$atleta->avatar)); ?>" alt="img-atleta"></td>
                    <td><?php echo e($atleta->nome); ?></td>
                    <td><?php echo e(App\Models\Atleta::posicao($atleta->posisao)); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($atleta->data_aniversario))); ?></td>

                    <td>
                        <a href="<?php echo e(route('atleta.edit', $atleta->id)); ?>" class="btn btn-sm "><img src="http://127.0.0.1:8000/storage/media/img/edit.png" width="30px"></a>


                            <form class="d-inline" method="POST" action="<?php echo e(route('atleta.destroy', $atleta->id )); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button onclick="return confirm('tem certeza que deseja excluir?')" class="btn btn-sm"><img src="http://127.0.0.1:8000/storage/media/img/del.png" width="30px"></button>
                            </form>

                    </td>
                </tr>
  </tbody>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
    </div>
    <div class="container-fluid desk">
      <?php echo e($atletas->links('pagination::bootstrap-4')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/atletas/index.blade.php ENDPATH**/ ?>