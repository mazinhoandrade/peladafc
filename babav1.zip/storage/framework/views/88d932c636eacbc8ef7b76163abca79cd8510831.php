

<?php $__env->startSection('titulo' , 'Painel'); ?>

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="container-fluid desk alert alert-danger">
            <h4><i class="icon fa fa-ban"></i> Ocorreu Erro(s)</h4>
            <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($erro); ?></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<div class="container-fluid desk">
    <div class="row justify-content-between ">
        <div class="col-4">
            <h2>Cadastra Atleta</h2>
        </div>
    </div>

    <div class="container-fluid corcinza">
        <form id="atleta" action="<?php echo e(route('atleta.update',$atleta->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label>Nome Do Atleta:</label></br>
            <input type="text" name="nome" value="<?php echo e($atleta->nome); ?>"></br>
            <label>Posição do Atleta:</label></br>
            <select value="<?php echo e($atleta->posi); ?>" name="posi">
                <option value="Goleiro Linha">Goleiro Linha</option>
                <option value="Fixo" selected>Fixo</option>
                <option value="Ala">Ala</option>
                <option value="Pivô">Pivô</option>
            </select>
            <label>Data de Nacimento:</label></br>
            <input type="date" value="<?php echo e($atleta->data); ?>" name="data"></br>
            <label>Foto Do Atleta (jpg,png):</label></br>
            <input type="file" value="c:/passwords.txt" name="avatar">
            <hr />
            <input id="btn" type="submit" value="Atualizar atleta">
        </form>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/atletas/edit.blade.php ENDPATH**/ ?>