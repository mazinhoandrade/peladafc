<div class="container-fluid desk">
    <div class="messagem">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\wamp64\www\babav1\resources\views/components/alert.blade.php ENDPATH**/ ?>