<!DOCTYPE html>
<html lang="pt-br">
<head>

</head>
<body>
olá

    




</body>
</html><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/menu.blade.php ENDPATH**/ ?>