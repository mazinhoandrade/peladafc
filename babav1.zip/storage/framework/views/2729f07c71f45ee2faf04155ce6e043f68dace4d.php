

<?php $__env->startSection('titulo' , 'Painel'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid desk">
        <div class="row justify-content-between info">
            <div class="col-4">
                <h2>seja bem vindo: <b>mazinho</b></h2>
            </div>
            <div class="col-4">
            <h3><a href="http://"><b>Sair</b></a></h3>
            </div>
        </div>
    </div>
</br>
    <div class="container-fluid desk">
        <div class="row justify-content-between ">
            <div class="col-4">
                <h2>Ficha dos Atletas</h2>
            </div>
            <div class="col-4">
            <h3><a href="/create"><b style="color: black;">Add Atleta</b></a></h3>
            </div>
        </div>
    </div>
    
    <div class="container-fluid desk corcinza">
    <table class="table">
  <thead>
    <tr>
      <th scope="col">#ID</th>
      <th scope="col">Foto</th>
      <th scope="col">Nome</th>
      <th scope="col">Posição</th>
      <th scope="col">Data De Nacimento</th>
      <th scope="col">Falhas</th>
      <th scope="col">Qtd Gols</th>
      <th scope="col">Qtd Assistecia</th>
      <th scope="col">Qtd de Capa</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\babav1\resources\views/admin/atleta.blade.php ENDPATH**/ ?>